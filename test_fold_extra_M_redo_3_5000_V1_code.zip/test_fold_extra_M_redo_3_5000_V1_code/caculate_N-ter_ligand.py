import numpy as np
import pandas as pd
import sys, os
from random import shuffle

from sklearn import metrics

import random

from random import choice



def readpdb_chain_N_C_alpha(filename, chains):
   cord = [None] * 3
   fr=open(filename,'r')
   arr_all=fr.readlines()
   fr.close()
   for line in arr_all:
      tem_B=' '
      if len(line)>16:
         tem_B=line[16]
         line=line[:16]+' '+line[17:]
      list_n = line.split()
      id = list_n[0]
      if id == 'ATOM' and tem_B !='B':
         type = list_n[2]
         chain_id=line[21:22]
         if  type == 'CA' and  list_n[3]!= 'UNK' and  chain_id in chains and line[21:26]=='A   1':
             type_of_chain = line[21:22]
             list_n[6]=line[30:38]
             list_n[7]=line[38:46]
             list_n[8]=line[46:54]
             position = list_n[6:9]
             break
   return   position


def readpdb_chain_ligand(filename):
   cord = [None] * 3
   Pposition={}
   ResinameP={}
   Atomline=[]
   fr=open(filename,'r')
   arr_all=fr.readlines()
   fr.close()
   for line in arr_all:
      tem_B=' '
      if len(line)>16:
         tem_B=line[16]
         line=line[:16]+' '+line[17:]
      list_n = line.split()
      id = list_n[0]
      if id == 'HETATM' :
         type = list_n[2]
         chain_id=line[21:22]
         residue = list_n[3]
         type_of_chain = line[21:22]
         tem1=line[22:26].replace("A", "")
         tem2=tem1.replace("B", "")
         tem2=tem2.replace("C", "")
         atom_count = line[4:11]+tem2+line[21:22]
         list_n[6]=line[30:38]
         list_n[7]=line[38:46]
         list_n[8]=line[46:54]
         position = list_n[6:9]
         Pposition[atom_count]=position
         list_n[4]=line[21:22]
         list_n[5]=line[22:26].replace(' ','')
         Pposition[atom_count]=position
   return   Pposition


def caculate_dis(filename):
    N_position = readpdb_chain_N_C_alpha(filename,'A')

    HLposition = readpdb_chain_ligand(filename)


    cord=list(HLposition.values())
    cord=np.array(cord).astype(float)
    avg=np.average(cord,axis=0)

    a = np.array(N_position)
    a1 = a.astype(np.float)
    b1=avg
    xx=np.subtract(a1,b1)
    tem=np.square(xx)
    tem1=np.sum(tem)
    out=np.sqrt(tem1)
    return  out


import glob

arr_files=glob.glob("complex*.pdb")

min_v=100000
min_key=''
for filename in arr_files:
     HLposition = readpdb_chain_ligand(filename)
     cord=list(HLposition.values())
     if  len(cord)>1:
        dis=caculate_dis(filename)
        #print dis, filename
        if   dis<min_v:
           min_key=filename
           min_v=dis

#print min_key,min_v
print min_key
















