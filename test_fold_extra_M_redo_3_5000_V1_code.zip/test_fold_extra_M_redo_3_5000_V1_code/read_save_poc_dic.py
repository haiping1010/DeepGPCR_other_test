import os
import sys
import numpy as np
from sklearn.cluster import KMeans
import numpy as np
from sklearn.cluster import KMeans
import glob
from torch_geometric.data import InMemoryDataset, DataLoader
from torch_geometric import data as DATA
import torch

from rdkit import Chem
from rdkit.Chem import MolFromSmiles
import networkx as nx


aa_dict=np.load('aa_vec_dic.npy', allow_pickle=True).item()


def residue_features(resname):
    seq=("ALA","ARG", "ASN", "ASP", "CYS", "GLU", "GLN", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",'Unkown')
    return np.array(one_of_k_encoding_unk(resname,seq))




def one_of_k_encoding_unk(x, allowable_set):
    """Maps inputs not in the allowable set to the last element."""
    if x not in allowable_set:
        x = allowable_set[-1]
    return list(map(lambda s: x == s, allowable_set))



def  pdb_graph(pdbfile):
  cord = [None] * 3
  uniq=[]
  Pposition={}
  ResinameP={}
  Interface=[]
  residuePair=[]
  for line in open(pdbfile):
     tem_B=' '
     if len(line)>16:
        tem_B=line[16]
        line=line[:16]+' '+line[17:]
     #print(line)
     list_n = line.split()
     id = list_n[0]
     if id == 'ATOM' and tem_B !='B' and line.find(" HOH ") == -1:
        type = list_n[2]
        #print (line)
        if type == 'CA' and list_n[3]!= 'UNK':
            residue = list_n[3]
            atomname=list_n[2]
            type_of_chain = line[21:22]
            tem1=line[22:26].replace("A", "")
            tem2=tem1.replace("B", "")
            tem2=tem2.replace("C", "")

            #tem2=filter(str.isdigit, list_n[5])
            #atom_count = tem2+line[21:22]
            atom_count = line[4:11]+line[21:22]
            cord[0]=line[30:38]
            cord[1]=line[38:46]
            cord[2]=line[46:54]
            position = cord[0:3]
            Pposition[atom_count]=position
            ResinameP[atom_count]=line[17:26]
            #print atom_count,hash[residue[0:3]+atomname]
  for key1, value1 in Pposition.items():
     for key2, value2 in Pposition.items():
         if key2>key1:
            a = np.array(value1)
            a1 = a.astype(np.float)
            b = np.array(value2)
            b1 = b.astype(np.float)
            xx=np.subtract(a1,b1)
            tem=np.square(xx)
            tem1=np.sum(tem)
            out=np.sqrt(tem1)
            if out<5 :
                residuePair.append([ResinameP[key1],ResinameP[key2]])
                uniq.append(ResinameP[key1])
                uniq.append(ResinameP[key2])
                Interface.append(a1)
  uniq_n=list(set(uniq))
  my_dict = {}
  for index, item in enumerate(uniq_n):
        my_dict[item] = index

  edges_p=[]
  features=[]
  for i in residuePair:
     #print ( my_dict[i[0]], my_dict[i[1]])
     edges_p.append([my_dict[i[0]], my_dict[i[1]]])
  for index, item in enumerate(uniq_n):
        #print (item)
        feature = aa_dict[item[0:3]]
        features.append( feature )
        #features.append( feature / sum(feature) )
  c_size=len(uniq_n)
  #print (c_size)
  return  c_size,features,edges_p



import glob

import sys


arr_all_poc=glob.glob("*_poc.pdb")

dict_n={}

for input_f  in arr_all_poc:
    print (input_f)

    dict_n[input_f.replace('_poc.pdb','').replace('AF-','').replace('-F1-model_v4','') ] =  pdb_graph(input_f)


import numpy as np

np.save('poc_dict.npy',dict_n)
new_dic=np.load('poc_dict.npy', allow_pickle='TRUE').item()

print (new_dic)



