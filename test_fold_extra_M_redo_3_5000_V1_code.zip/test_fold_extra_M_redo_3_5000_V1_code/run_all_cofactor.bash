
export   pkgdir=/home/zhanghaiping/protein_folding/I-TASSER5.1

export   datafiledir=/home/zhanghaiping/work/GPCR_2/gpcrlig2/test_fold_extra_M
#aa=$1

for aa  in   AF*-F1-model_v4.pdb
do
nohup  perl $pkgdir/I-TASSERmod/runCOFACTOR.pl  -libdir  $pkgdir/libdir  -protname ${aa%.pdb}   -model  $aa  -datadir  $datafiledir  -outdir  $datafiledir'/'${aa%.pdb} > $aa'.log' 2>&1&

sleep  10s
done


