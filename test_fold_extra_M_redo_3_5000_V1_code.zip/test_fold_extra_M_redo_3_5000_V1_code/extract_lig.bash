

for name in    *_complex.pdb
do

	base=${name%_complex.pdb}
	grep "^ATOM\|^TER\|^END" $base'.pdb' > $base'_w.pdb' 
	grep  "HETATM"  $name  >$base'_ligand_n.pdb'
	babel -ipdb  $base'_ligand_n.pdb'   -omol2 $base'_ligand_n.mol2'
        nohup  python  extract_pocket.py  $base >$base'_xx.log'  2>&1&
	sleep 1s




done
