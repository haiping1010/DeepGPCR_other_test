import glob
import numpy as np
arr_pos_lig=glob.glob("positive_n/??????/*.smi")

arr_neg_lig=glob.glob("negative_n/??????/*.smi")


dict_p_n={}

for name in arr_pos_lig:
    tem_arr=name.split('/')
    dict_p_n[tem_arr[1]+'_'+tem_arr[2].replace('.smi','')] = 1

for name in arr_neg_lig:
    tem_arr=name.split('/')
    dict_p_n[tem_arr[1]+'_'+tem_arr[2].replace('.smi','')] = 0


np.save('Orig_pos_neg.npy', dict_p_n)

dict_load=np.load('Orig_pos_neg.npy', allow_pickle=True).item()

