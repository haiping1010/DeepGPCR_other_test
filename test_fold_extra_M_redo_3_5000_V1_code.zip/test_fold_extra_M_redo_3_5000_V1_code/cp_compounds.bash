
mkdir negative
mkdir positive
for name in AF-??????-F1-model_v4
do

base=${name:3:6 }

echo $base

cp -r   ~/GPCR_related/GPCR_n_n/negative/$base   negative/
cp -r   ~/GPCR_related/GPCR_n_n/positive/$base   positive/



done
