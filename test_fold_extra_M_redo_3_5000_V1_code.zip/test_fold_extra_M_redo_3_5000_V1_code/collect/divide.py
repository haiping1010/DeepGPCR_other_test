
fr=open('output_n.txt','r')

arr=fr.readlines()
tem_arr=[]
for line in arr:
    tem_arr.append(line[0:6])

print ( list(set(tem_arr)) )
uniq=list(set(tem_arr))

for  code_n in  uniq:
    fw=open(code_n+"_each.list", 'w')
    for line  in arr:
         if  line[0:6] == code_n:
              fw.write(line)
    fw.close()
