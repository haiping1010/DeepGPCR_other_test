cat   download.txt  | while read  line
do


base=${line:0:6}

wget 'https://alphafold.ebi.ac.uk/files/AF-'$base'-F1-model_v4.pdb'


done

