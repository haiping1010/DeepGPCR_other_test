for name in ??????
do
cd $name


nohup bash  ../part1.bash &
#bash ../part1.bash
sleep 1s
: '
for file in *.sdf
do
        base=${file%.sdf}
        babel -isdf $file  -osmi  $base'.smi'


done
'
cd ..
done

