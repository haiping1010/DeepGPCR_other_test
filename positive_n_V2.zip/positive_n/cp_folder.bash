

cat  list.txt  | while read line
do

cp  -r   /data/hpzhang/GPCR_n_n_creat_neg5_3000/positive/$line  .



done
