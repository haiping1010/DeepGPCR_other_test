for file in *.sdf
do
        base=${file%.sdf}
        babel -isdf $file  -osmi  $base'.smi'


done

