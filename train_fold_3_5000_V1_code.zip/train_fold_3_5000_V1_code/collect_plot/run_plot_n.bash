
gnuplot -c 'plot.p_bc2'  

mv hbond.png   hbond_1_test.png

gnuplot -c 'plot.p_bc3'  

mv hbond.png   hbond_2_train.png







