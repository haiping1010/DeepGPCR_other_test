for name in  AF-??????-F1-model_v4
do

base=${name%.pdb}

cd  $name/$name'/cofactor/BSITE_'$name
filename=`python   ../../../../caculate_N-ter_ligand.py`

cd  ../../../../


cp  -r $name/$name'/cofactor/BSITE_'$name'/'$filename  $base'_complex.pdb'

cp  -r $name/$name'/cofactor/BSITE_'$name'/'$filename  'mark_'$base'_'$filename


done
