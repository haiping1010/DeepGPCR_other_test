

import glob
import numpy as np
from sklearn import metrics


from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import f1_score

def acc(true, pred):

    return np.sum(true == pred) * 1.0 / len(true)

def aucJ(true_labels, predictions):

    fpr, tpr, thresholds = metrics.roc_curve(true_labels, predictions, pos_label=1)
    auc = metrics.auc(fpr,tpr)

    return auc



arr_file=glob.glob("*_each.list")



#print (dict_load.keys())
pred=[]
G=[]
cutoff=0.5
for  filename in arr_file:
          pred=[]
          P=[]
          G=[]
          dict_aff={}
          base_n=filename.replace('_each.list','')
          fr_n=open(filename,'r')
          arr_name=fr_n.readlines()
          for  name in arr_name:
                  arr_tem_n=name.strip().split("\t")
                  #print arr_tem_n[1],dict_aff.keys()[0]
                  pred.append(float(arr_tem_n[2]))
                  G.append(float(arr_tem_n[1]))




          P=pred[:]
          G=np.array(G)
          P=np.array(P)
          print (G,P)
          auc = aucJ(G, P)
          print ('Name:',base_n)
          print ("AUC:",auc)
          threshold=0.5
          P[P > threshold] = 1
          P[P <= threshold] = 0
          pos_index = P == 1

          pos_index = pos_index.flatten()

          TPR = np.sum(G[pos_index] == 1) * 1.0 / np.sum(G)
          print("TPR: ", TPR)
          precision = np.sum(G[pos_index] == 1) * 1.0 / np.sum(P)
          print("precision: ", precision)
          #auc = aucJ(label, pred)
          accuracy = acc(G, P)
          print ("accuracy: ", accuracy)
          MCC=matthews_corrcoef(G, P)
          print("MCC: ", MCC)
          F1 = f1_score(G, P)
          print("F1 score: ", F1)


          print("pos_num:", np.sum(G == 1) )
          print("neg_num:", np.sum(G == 0) )
          print("total_num",len(G))


           


